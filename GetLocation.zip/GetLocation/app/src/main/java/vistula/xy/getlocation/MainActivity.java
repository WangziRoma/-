package vistula.xy.getlocation;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    private MapView mapView;
    private GoogleMap googleMap;
    private DatabaseReference locationsRef;
    private Marker currentMarker;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapView = findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        locationsRef = database.getReference("locations");

        // Retrieve location data from Firebase
        locationsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                LocationData lastLocationData = null;

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    lastLocationData = snapshot.getValue(LocationData.class);
                }

                if (lastLocationData != null) {
                    updateMarkerAndUI(lastLocationData.getLatitude(), lastLocationData.getLongitude());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        // You can customize the map settings here
    }

    private void updateMarkerAndUI(double latitude, double longitude) {
        LatLng location = new LatLng(latitude, longitude);

        if (googleMap != null) {
            if (currentMarker == null) {
                currentMarker = googleMap.addMarker(new MarkerOptions().position(location));
            } else {
                currentMarker.setPosition(location);
            }

            googleMap.moveCamera(CameraUpdateFactory.newLatLng(location));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
